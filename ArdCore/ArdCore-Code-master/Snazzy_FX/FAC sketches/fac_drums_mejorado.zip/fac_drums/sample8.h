#ifndef sample8_header
#define sample8_header

#include <avr/pgmspace.h>

#define sample8_size 1151
#define sample8_fs_micro 0.0220f

extern prog_uchar sample8_data[sample8_size];

#endif
