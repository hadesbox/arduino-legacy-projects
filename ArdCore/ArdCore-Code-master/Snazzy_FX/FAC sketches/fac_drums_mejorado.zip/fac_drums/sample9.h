#ifndef sample9_header
#define sample9_header

#include <avr/pgmspace.h>

#define sample9_size 1530
#define sample9_fs_micro 0.0110f

extern prog_uchar sample9_data[sample9_size];

#endif
