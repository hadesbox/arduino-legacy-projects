#ifndef sample4_header
#define sample4_header

#include <avr/pgmspace.h>

#define sample4_size 1632
#define sample4_fs_micro 0.0240f

extern prog_uchar sample4_data[sample4_size];

#endif
