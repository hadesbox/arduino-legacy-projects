dRUMmACHINE
===========

Pot controlled arduino midi drum machine based on the concept of Mutble Instrument's Anushri drum sequencer.
