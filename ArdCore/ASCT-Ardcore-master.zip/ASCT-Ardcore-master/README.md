ASCT-Ardcore
============

## WARNING

###These are all work in progress sketches, so may be incomplete, totally broken etc.... i take no responibility for them damaging your ardcore, modules or mind. That being said i will do my best not to upload anything totally borked.


## Current Sketches

#ASCTard001 - Analytic Geometry

	CV sequencer based on co-ordinate locations. Look at the readme

#ASCTard002 - CV Scaler

	Super basic cv scaler where you set min/max on a0/a1 and cv input on a3. a4 does nothing

#ASCTard004 - Gate/trigger Counter

	counter and flipflop 

#ASCTard005- Experimental LFO

	LFO based on the mozzi arduino objects, you MUST have mozzi installed for this to work and it comes with some caveats, see the sketch for info

#ASCTard006- Burst Generator

	Simple burst generator, more to do......

#ASCTard007- Rat(S)h(*)t

	Trigger generator based very very loosely on some of the ideas in the Buchla/Eardrill Pendulum Ratchet module, designed to replicate some outputs from the a and b output sections, so clock is divided as well as being tested against some number tables. More number tables and counter methods to be added soon (and ones that give more data back so you dont need as fast a clock input, blah blah blah.....)




## Thanks:

#Darwin Grosse
	I would urge you to check out his ardcore github https://github.com/darwingrosse/ArdCore-Code
	Most of the setup and helper functions in these are shamelessly borrowed from his excellent template, if you want to learn about the ardcore his sketches are the place to start. Maximum respect :D

#Snazzyfx
	Dans a great guy and the eurorack 'ardcore is ridiculously awesome, snazzyfx rule! 

Ascetic 2013