#include "sample4.h"

prog_uchar sample4_data[sample4_size] = {
	
};

