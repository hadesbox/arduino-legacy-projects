#ifndef sample6_header
#define sample6_header

#include <avr/pgmspace.h>

#define sample6_size 0
#define sample6_fs_micro 0.0000f

extern prog_uchar sample6_data[sample6_size];

#endif
