#ifndef sample1_header
#define sample1_header

#include <avr/pgmspace.h>

#define sample1_size 754
#define sample1_fs_micro 0.0160f

extern prog_uchar sample1_data[sample1_size];

#endif
