#include "sample6.h"

prog_uchar sample6_data[sample6_size] = {
	
};

