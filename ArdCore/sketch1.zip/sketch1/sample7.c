#include "sample7.h"

prog_uchar sample7_data[sample7_size] = {
	
};

