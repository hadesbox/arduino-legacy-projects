#ifndef CV_TABLE_HEADER
#define CV_TABLE_HEADER

#include <avr/pgmspace.h>

extern prog_uint32_t cv_table[1024];

#endif
