#ifndef OFFSET_TABLE_HEADER
#define OFFSET_TABLE_HEADER

#include <avr/pgmspace.h>

extern prog_uint32_t offset_table[1024];

#endif
