#ifndef PITCH_TABLE_HEADER
#define PITCH_TABLE_HEADER

#include <avr/pgmspace.h>

extern prog_uint32_t pitch_table[2048];

#endif
