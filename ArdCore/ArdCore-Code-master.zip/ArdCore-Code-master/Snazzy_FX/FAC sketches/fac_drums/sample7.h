#ifndef sample7_header
#define sample7_header

#include <avr/pgmspace.h>

#define sample7_size 1632
#define sample7_fs_micro 0.0220f

extern prog_uchar sample7_data[sample7_size];

#endif
