This is the location for all ArdCore source produced by 20 Objects LLC.
Please see http://www.20objects.com for more information.

Files with the AC prefix are general-use ArdCore sketches. Files with
the OX prefix are specifically created for use with the output expander.

Note: When you first try to load these files into the Arduino
editor/loader, it will prompt you to create a folder that contains this
file. Please allow the system to do what it has to do...!