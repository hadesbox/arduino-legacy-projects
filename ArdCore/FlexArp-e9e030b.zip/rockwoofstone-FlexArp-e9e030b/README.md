FlexArp is a flexible arpeggiator for the SnazzyFX ardcore Eurorack module. It should also work on any other ardcore implementation.

Provides control of:

* Scale of the arpeggio
* Root note of the arpeggio in the selected scale
* Distance in scale notes between each arpeggio step
* Number of steps in the arpeggio
* Mode of playback of the arpeggio
* Number of octaves the arpeggio is repeated over
* Configuration of control layout and behaviour

