#ifndef _MIDI_SETUP_H_
#define _MIDI_SETUP_H_

#include <inttypes.h>

void MIDI_Setup();
void MIDI_Read();

#endif

